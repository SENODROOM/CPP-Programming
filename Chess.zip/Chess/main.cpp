#include <SFML/Graphics.hpp>
#include <iostream>
#include <fstream>
#include "play.h"
using namespace sf;
int main(){
	play p;
	return 0;
}